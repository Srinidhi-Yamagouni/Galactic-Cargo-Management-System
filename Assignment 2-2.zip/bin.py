from avl import AVLTree, comparator_object
from node import Node
from object import Object
class Bin:
    def __init__(self, bin_id, capacity):
        self.bin_id=bin_id
        self.capacity=capacity
        self.obj= AVLTree(comparator_object)

    def add_object(self, object):
        # Implement logic to add an object to this bin
        node = Node(object)
        self.obj.insert(node)
        self.capacity-=object.size
        object.bin_id=self.bin_id

    def remove_object(self, object_id):
        # Implement logic to remove an object by ID
        node = self.obj._find_by_id(self.obj.root, object_id)
        self.capacity+=node.data.size
        self.obj.delete(node)