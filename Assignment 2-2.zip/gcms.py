from bin import Bin
from avl import AVLTree, comparator_bin_id_bin_capacity, comparator_bin_id_bin_instance, comparator_object
from object import Object, Color
from exceptions import NoBinFoundException
from node import Node

class GCMS:
    def __init__(self):
        self.bin_id_inst = AVLTree(comparator_bin_id_bin_instance) 
        self.bin_cap_id = AVLTree(comparator_bin_id_bin_capacity)
        self.o = AVLTree(comparator_object)

    def add_bin(self, bin_id, capacity):
        self.bin_id_inst.insert(Node((bin_id, Bin(bin_id, capacity))))
        self.bin_cap_id.insert(Node((capacity, bin_id)))

    def add_object(self, object_id, size, color):
        object = Object(object_id, size, color)
        obj_node = Node(object)

        if color == Color.GREEN:
            node = self.suit_bin_green(size)
        elif color == Color.RED:
            node = self.suit_bin_red(size)    
        elif color == Color.BLUE:
            node = self.suit_bin_blue(size)
        elif color == Color.YELLOW:
            node = self.suit_bin_yellow(size)

        if not node or node.data[0] < size:
            raise NoBinFoundException()

        cap = node.data[0]
        id = node.data[1]
        bin_node = self.bin_id_inst._find_by_id(self.bin_id_inst.root, node.data[1])
        bin_node.data[1].add_object(object)
        new_node=Node((cap - object.size, id))
        self.bin_cap_id.delete(node)
        self.bin_cap_id.insert(Node((cap - object.size, id)))
        self.o.insert(obj_node)
    

    def suit_bin_green(self, size):
        if size > self.bin_cap_id._subtree_last_node(self.bin_cap_id.root).data[0]:
            return None
        return self.bin_cap_id._subtree_last_node(self.bin_cap_id.root)
    
    def suit_bin_red(self, size):
        if size > self.bin_cap_id._subtree_last_node(self.bin_cap_id.root).data[0]:
            return None

        max_node = self.suit_bin_green(size)
        max_cap = max_node.data[0]
        node = self.bin_cap_id.root
        best_node = None

        while node:
            if node.data[0] < max_cap:
                node = node.right
            elif node.data[0] == max_cap:
                if best_node is None or node.data[1] < best_node.data[1]:  # Ensure the smallest ID
                    best_node = node
                node = node.left
            else:
                break

        return best_node
    
    def suit_bin_blue(self, size):
        node = self.bin_cap_id.root
        best_node = None
        while node:
            if node.data[0] >= size:
                best_node = node
                node = node.left
            else:
                node = node.right
        return best_node

    def suit_bin_yellow(self, size):
        cap_node = self.suit_bin_blue(size)
        if not cap_node:
            return None
        cap = cap_node.data[0]
        node = self.bin_cap_id.root
        best_node = None

        while node:
            if node.data[0] < cap:
                node = node.right
            elif node.data[0] > cap:
                node = node.left
            elif node.data[0] == cap:
                if best_node is None or node.data[1] > best_node.data[1]:  # Ensure the smallest ID
                    best_node = node
                node = node.right
            else:
                break

        return best_node

    def delete_object(self, object_id):
        object_node = self.o._find_by_id(self.o.root, object_id)
        if object_node:
            bin_id = object_node.data.bin_id
            bin_node = self.bin_id_inst._find_by_id(self.bin_id_inst.root, bin_id)
            cap = bin_node.data[1].capacity
            bin_node.data[1].remove_object(object_id)
            self.o.delete(object_node)
            nnode=self.bin_cap_id._find_by_id(self.bin_cap_id.root,(cap, bin_id) )
            self.bin_cap_id.delete(nnode)
            self.bin_cap_id.insert(Node((bin_node.data[1].capacity, bin_node.data[1].bin_id)))

    def bin_info(self, bin_id):
        node = self.bin_id_inst._find_by_id(self.bin_id_inst.root, bin_id)
        bin_tree = node.data[1].obj
        ls = []
        for obj in bin_tree.inorder():
            ls.append(obj.object_id)
        return (node.data[1].capacity, ls)

    def object_info(self, object_id):
        node = self.o._find_by_id(self.o.root, object_id)
        if node is None:
            return None
        return node.data.bin_id