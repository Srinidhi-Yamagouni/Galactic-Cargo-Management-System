from node import Node
from object import Object

class AVLTree:
    def __init__(self, comparator):
        self.root = None
        self.size = 0
        self.comparator = comparator

    def height(self, node):
        if node is not None:
            return node.height
        else:
            return -1

    def recompute_height(self, node):
        if node:
            node.height = 1 + max(self.height(node.left), self.height(node.right))

    def is_balanced(self, node):
        return abs(self.height(node.left) - self.height(node.right)) <= 1

    def tall_child(self, node, favorleft=False):
        if self.height(node.left) + (1 if favorleft else 0) > self.height(node.right):
            return node.left
        else:
            return node.right

    def tall_grandchild(self, node):
        child = self.tall_child(node)
        alignment = (child == node.left)
        return self.tall_child(child, alignment)
    
    def _restructure(self, x):
        y = x.parent
        z = y.parent
        
        if x == y.left and y == z.left:
            return self._rotate_right(z)
        elif x == y.right and y == z.right:
            return self._rotate_left(z)
        elif x == y.right and y == z.left:
            self._rotate_left(y)
            return self._rotate_right(z)
        else:
            self._rotate_right(y)
            return self._rotate_left(z)

    def _rotate_left(self, z):
        y = z.right
        z.right = y.left
        if y.left:
            y.left.parent = z
        y.parent = z.parent
        if not z.parent:
            self.root = y
        elif z == z.parent.left:
            z.parent.left = y
        else:
            z.parent.right = y
        y.left = z
        z.parent = y
        self.recompute_height(z)
        self.recompute_height(y)

    def _rotate_right(self, z):
        y = z.left
        z.left = y.right
        if y.right:
            y.right.parent = z
        y.parent = z.parent
        if not z.parent:
            self.root = y
        elif z == z.parent.right:
            z.parent.right = y
        else:
            z.parent.left = y
        y.right = z
        z.parent = y
        self.recompute_height(z)
        self.recompute_height(y)

    def _rebalance(self, p):
        while p is not None:
            self.recompute_height(p)
            if not self.is_balanced(p):
                x = self.tall_grandchild(p)
                if x and x.parent and x.parent.parent:
                    self._restructure(x)
            p = p.parent

    def insert(self, node):
        if not self.root:
            self.root = node
        else:
            current = self.root
            parent = None
            while current:
                parent = current
                if self.comparator(node, current):
                    current = current.left
                else:
                    current = current.right

            if self.comparator(node, parent):
                parent.left = node
            else:
                parent.right = node

            node.parent = parent
            self._rebalance(node.parent)

    def inorder(self):
        def _inorder(node):
            if node is not None:
                yield from _inorder(node.left)
                yield node.data
                yield from _inorder(node.right)
        return list(_inorder(self.root))

    def delete(self, node):
        if not node:
            return node
        if node.left and node.right:
            replacement = self._subtree_last_node(node.left)
            node.data = replacement.data
            node = replacement

        parent = node.parent
        if node.left:
            child = node.left
        else:
            child = node.right

        if child is not None:
            child.parent = parent

        if parent is None:
            self.root = child
        else:
            if node == parent.left:
                parent.left = child
            else:
                parent.right = child

        self.size -= 1

        if parent:
            self._rebalance(parent)
        elif child:
            self._rebalance(child)

    def _find_by_id(self, node, id):
        if node is None:
            return None
        if isinstance(node.data, Object):
            if id == node.data.object_id:
                return node
            elif id < node.data.object_id:
                return self._find_by_id(node.left, id)
            else:
                return self._find_by_id(node.right, id)
            
        elif isinstance(node.data, tuple) and isinstance(id, tuple):
            if id == node.data:
                return node
            elif id < node.data:  # Here, the full tuple is compared
                return self._find_by_id(node.left, id)
            else:
                return self._find_by_id(node.right, id)
        
                    
        elif isinstance(node.data[0], int):
            if id == node.data[0]:
                return node
            elif id < node.data[0]:
                return self._find_by_id(node.left, id)
            else:
                return self._find_by_id(node.right, id)

        
    def _subtree_last_node(self, p):
        while p.right is not None:
            p = p.right
        return p
    
    def _subtree_first_node(self, p):
        while p.left is not None:
            p = p.left
        return p

# Comparators for each tree type
def comparator_bin_id_bin_instance(node1, node2):
    return node1.data[0] < node2.data[0]

def comparator_bin_id_bin_capacity(node1, node2):
    return node1.data[0] < node2.data[0] or (node1.data[0] == node2.data[0] and node1.data[1] < node2.data[1])

def comparator_object(node1, node2):
    return node1.data.object_id < node2.data.object_id

